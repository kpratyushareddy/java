package source1;
import java.util.*;
import java.io.*;

 class Personal implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5383137529824932039L;
	String fname;
	String lname;
	String add;
	String email;
	String pwd;
	float bal;
	double phno;
     Personal (String f,String l,String a,String e,String pass,float b,double ph)
     {
    	fname=f;
    	lname=l;
    	add=a;
    	email=e;
    	pwd=pass;
    	bal=b;
    	phno=ph;
     }
     String getFirstName()
 	{
 		return fname ; 
 		
 	}
     String getLastName()
  	{
  		return lname ; 
  		
  	}
     String getEmail()
  	{
  		return email ; 
  		
  	}
     String getAddress()
  	{
  		return add ; 
  		
  	}
     String getPassword()
  	{
  		return pwd ; 
  		
  	}
    float getBalance()
   	{
   		return bal ; 
   		
   	}
     double getPhonenum()
  	{
  		return phno ; 
  		
  	}
     
}
class Personalaccount
{ 
	int rand1;
	boolean flag=false;
	 Scanner s=new Scanner(System.in);
	@SuppressWarnings("unchecked")
	void getDetails() throws IOException, ClassNotFoundException
	{
	
	String f,l,a,e,pass;
	double ph;
  float b;
	System.out.println("enter ussername-email");
	e=s.next();
	FileInputStream fos1=new FileInputStream("paypal/personal1.txt");
    ObjectInputStream out1=new  ObjectInputStream(fos1);
	 ArrayList<Personal>p1 =new ArrayList<Personal>();
   p1=(ArrayList<Personal>)out1.readObject();
    for(int i=0;i<p1.size();i++)
    {
    	while(p1.get(i).email==e)
    	{
    		System.out.println("user already exists try with another email-id");
    		System.out.println("enter ussername-email");
    		e=s.next();
    	}
    }
    
    System.out.println("enter first name");
	f=s.next();
	System.out.println("enter last name ");
	l=s.next();
	System.out.println("enter phone num");
	ph=s.nextDouble();
	System.out.println(" enter address");
	a=s.next();  
	System.out.println("enter password");
	pass=s.next();
	System.out.println("enter minimum balance for an account ");
	b=s.nextFloat();


	FileOutputStream fos12=new FileOutputStream("paypal/personal1.txt");
    ObjectOutputStream out=new  ObjectOutputStream(fos12 );
	p1.add(new Personal(f,l,a,e,pass,b,ph));
    out.writeObject(p1);
	out.close();
		out1.close();
	 System.out.println("account created successfully");
	}
	  
    public void activation()
    {
    	Random rand = new Random(); 
    	System.out.println("generating activation code");
    	rand1=rand.nextInt();
    	System.out.println("generated activated  code"+rand1);
    	//return rand1;
    	
    }
    boolean  checkActivation()
    {
    	System.out.println("enter the generated activation code");
    	System.out.println(rand1);
    	int rand2=s.nextInt();
    	if(rand2==rand1)
    	{
    		System.out.println("account activated");
    		flag=true;
    	}
    	else
    	{
    		System.out.println("account not ativted try again");
    	}
    	return flag;
    }
    
	public static void main(String[] args)throws Exception
	{
		Personalaccount p2=new Personalaccount();
		p2.getDetails();
		p2.activation();
		p2.checkActivation();
	}
}
