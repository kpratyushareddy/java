package source1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Studentoperations
{
	int flag=0,j;
	float l;
	String mail;
	//String ttime,tday;
	Scanner s=new Scanner(System.in);
	 @SuppressWarnings("unchecked")
	void credit() throws IOException, ClassNotFoundException
		{
		 float c;
		 System.out.println("enter money to credit");
		 c=s.nextFloat();
		 System.out.println("enter parents  mailid");
		 mail=s.next();
		 FileInputStream fos=new FileInputStream("paypal/personal1.txt");
	     @SuppressWarnings("resource")
		ObjectInputStream out=new  ObjectInputStream(fos);
	 	ArrayList<Personal>p;
	 	Personal ac1;
	     p=(ArrayList<Personal>)out.readObject();
	     for(j=0;j<p.size();j++)
		    {
	     	if(p.get(j).email.equals(mail))
	     	{
	     		l=p.get(j).bal;
	     		break;
	     	}
	     	else
	    	{
	    		System.out.println("parents mail is not registered");
	    	}
		    }
		
	      l=l+c;
		  flag=1;
			System.out.println("balance in the current account is "+l);
			 Date objDate = new Date(); // Current System Date and time is assigned to objDate
			  System.out.println(objDate);
			  FileOutputStream fos1=new FileOutputStream("paypal/personal1.txt");
		        ObjectOutputStream out1=new  ObjectOutputStream(fos1);
              ac1=p.get(j);
	        	p.remove(p.get(j));
	        	ac1.bal=l;
	        	p.add(ac1);
	        	out1.writeObject(ac1);
	        	out1.close();
			  System.out.println("accoutn logout ");
			}
		
		@SuppressWarnings("unchecked")
		void debit() throws IOException, ClassNotFoundException
		{
			System.out.println("enter money to withdraw");
			float d=s.nextFloat();
			 FileInputStream fos=new FileInputStream("paypal/personal1.txt");
		     @SuppressWarnings("resource")
			ObjectInputStream out=new  ObjectInputStream(fos);
		 	ArrayList<Personal>p;
		 	Personal ac1;
		     p=(ArrayList<Personal>)out.readObject();
		     for(j=0;j<p.size();j++)
			    {
		     	if(p.get(j).email.equals(mail))
		     	{
		     		l=p.get(j).bal;
		     		break;
		     	}
		     	else
		    	{
		    		System.out.println("parents mail is not registered");
		    	}
			    }
			if(d>5000)
			{
				 System.out.println("user is not permittted to withdraw that amount ");
			}
			else
			{
			if(l<d)
			   {
				System.out.println("balance is low");	  
			       }
		    else
			  {
			     l=l-d;
			     flag=1;
			       System.out.println("balance in the account is "+l);
			       FileOutputStream fos1=new FileOutputStream("paypal/personal1.txt");
			        ObjectOutputStream out1=new  ObjectOutputStream(fos1);
	              ac1=p.get(j);
		        	p.remove(p.get(j));
		        	ac1.bal=l;
		        	p.add(ac1);
		        	out1.writeObject(ac1);
		        	out1.close();
			       Date objDate = new Date(); // Current System Date and time is assigned to objDate
					  System.out.println(objDate); 
			       
			    }
		   
		   if(flag==1)
		 {
			 System.out.println("transaction completd"); 
		 }
		 else
		 {
			 System.out.println("transaction failed");  
		 }
		   System.out.println("accoutn logout ");
			}
		} 
}
		
		


