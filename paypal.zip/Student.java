package source1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

class Studentaccount  implements Serializable
{
	String fname;
	String lname;
	String add;
	String email;
	String pwd;
	String pmailid;
	double phno;
     Studentaccount (String f,String l,String a,String e,String pass,String pmail,double ph)
     {
    	fname=f;
    	lname=l;
    	add=a;
    	email=e;
    	pwd=pass;
    	pmailid=pmail;
    	phno=ph;
    	
     }
     String getFirstName()
 	{
 		return fname ; 
 		
 	}
     String getLastName()
  	{
  		return lname ; 
  		
  	}
     String getEmail()
  	{
  		return email ; 
  		
  	}
     String getAddress()
  	{
  		return add ; 
  		
  	}
     String getPassword()
  	{
  		return pwd ; 
  		
  	}
     String getPmailid()
   	{
   		return pmailid ; 
   		
   	}
     double getPhonenum()
  	{
  		return phno ; 
  		
  	}
     
}


public class Student 
{
	int rand1;
		boolean flag=false;
		 Scanner s=new Scanner(System.in);
				@SuppressWarnings({ "unchecked", "resource" })
				void getDetails() throws IOException, ClassNotFoundException
		{
		
		String f,l,a,e,pass,pmail;
		double ph;
	   //float b;
		System.out.println("enter ussername-email");
		e=s.next();
		FileInputStream fos1=new FileInputStream("paypal/student.txt");
	    ObjectInputStream out1=new  ObjectInputStream(fos1);
		 
	    ArrayList<Studentaccount>s1=new ArrayList<Studentaccount>() ;
	   
	    s1=(ArrayList<Studentaccount>)out1.readObject();
	   	    int i=0;
			do
	        {
	    	while(s1.get(i).email.equals(e))
	    	{
	   		System.out.println("user already exists try with another email-id");
	    		System.out.println("enter ussername-email");
	    		e=s.next();
	    	}
	        }while(i>s1.size());
	 
				
	  System.out.println("enter first name");
		f=s.next();
		System.out.println("enter last name ");
		l=s.next();
		System.out.println("enter phone num");
		ph=s.nextDouble();
		System.out.println(" enter address");
		a=s.next();  
		System.out.println("enter password");
		pass=s.next();
		System.out.println("enter parentsmail");
		pmail=s.next();
		FileInputStream fos=new FileInputStream("paypal/personal1.txt");
        ObjectInputStream out12=new  ObjectInputStream(fos);
		 ArrayList<Personal>p1;
		    p1=(ArrayList<Personal>)out12.readObject();
		    for(int j=0;j<p1.size();j++)
		    {
		    	if(p1.get(j).email.equals(pmail))
		    	{
		    		System.out.println("parents email valid");
		    		break;
		    	}
		    	else
		    	{
		    		System.out.println("parents email  invalid");
		    	}
		    }
		 FileOutputStream fos11=new FileOutputStream("paypal/student.txt"); 
		    ObjectOutputStream out=new  ObjectOutputStream(fos11); 
		  
		s1.add(new Studentaccount(f,l,a,e,pass,pmail,ph));
	    out.writeObject(s1);
		out.close();
		//out1.close();

		}
		
		  
	    public void activation()
	    {
	    	Random rand = new Random(); 
	    	System.out.println("generating activation code");
	    	rand1=rand.nextInt();
	    	System.out.println("generated activated  code"+rand1);
	    	//return rand1;
	    	
	    }
	    boolean  checkActivation()
	    {
	    	System.out.println("enter the generated activation code");
	    	System.out.println(rand1);
	    	int rand2=s.nextInt();
	    	if(rand2==rand1)
	    	{
	    		System.out.println("account activated");
	    		flag=true;
	    	}
	    	else
	    	{
	    		System.out.println("account not ativted try again");
	    	}
	    	return flag;
	    }
	    
	
	

	public static void main(String[] args) throws ClassNotFoundException, IOException
	{
		 Student st1=new  Student();
		 st1.getDetails();
		 st1.activation();
		st1.checkActivation();
		 
	}

}
