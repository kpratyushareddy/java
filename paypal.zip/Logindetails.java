package source1;
import java.util.*;
import java.io.*;
public class Logindetails
{
	String emailid;
	String password;
	int flag1=0;
	int op,k;
        Scanner s=new Scanner(System.in);
        
	@SuppressWarnings("unchecked")
	public int getLogin() throws IOException, Exception
    {
    	
         System.out.println("enter ussername-email");
     	emailid=s.next();
     	System.out.println("enter password");
    	password=s.next();
    	FileInputStream fos=new FileInputStream("paypal/personal1.txt");
        @SuppressWarnings("resource")
		ObjectInputStream out=new  ObjectInputStream(fos);
        ArrayList<Personal>p;
        p=(ArrayList<Personal>)out.readObject();
      for(int i=0;i<p.size();i++)
        {
        	if((p.get(i).email.equals(emailid))&&(p.get(i).pwd.equals(password)))
        	{
        		System.out.println("loginsuccess");
        		System.out.println("registered user name"+p.get(i).fname);
        		System.out.println("registered user mail"+p.get(i).email);
         	   System.out.println("registered user accountbalance"+p.get(i).bal);
        		flag1=1;
        		k=i;
        		
        	}
        	
    	 /* System.out.println("----------------");
    	   System.out.println("registered user amail"+p.get(i).email);
    	   System.out.println("registered user password"+p.get(i).pwd);
    	   System.out.println("registered user password"+p.get(i).bal);
    	   System.out.println("----------------");*/
        }
      return  flag1;
      }
	/*void display()
	{
		
	}*/
    public void getOptions() throws ClassNotFoundException, IOException
    {
    	 System.out.println("select your option");
    	 System.out.println("1:add money \n2:withdraw money\n\n3:request to send money\n4:exit/logout");
    	 int op=s.nextInt();
    	 switch(op)
    	 {
    	 case 1:
    		 Operations o=new Operations();
    		 o.credit();
    		 break;
    	 case 2: Operations o1=new Operations();
		 o1.debit();
    		break;
    	    case 3:
    		 Operations o3=new Operations(); 
    		 o3.requestToSend();
    		 break;
    	 }
    }
}
 
    
    
    /*public static void main(String[] args)throws Exception
	{
    	Logindetails v=new Logindetails ();
    	Personal a=new Personal(emailid, emailid, emailid, emailid, emailid, 0, 0);
	}*/






