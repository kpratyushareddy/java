package source1;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Studentlogin 
{

	String emailid;
	String password;
	int flag1=0;
	int op,k;
        Scanner s=new Scanner(System.in);
	@SuppressWarnings("unchecked")
	public int getLogin() throws IOException, Exception
    {
    	FileInputStream fos=new FileInputStream("paypal/student.txt");
        ObjectInputStream out=new  ObjectInputStream(fos);
         System.out.println("enter ussername-email");
     	emailid=s.next();
     	System.out.println("enter password");
    	password=s.next();
    	ArrayList<Studentaccount>st;
        st=(ArrayList<Studentaccount>)out.readObject();
      for(int i=0;i<st.size();i++)
        {
        	if((st.get(i).email.equals(emailid))&&(st.get(i).pwd.equals(password)))
        	{
        		System.out.println("loginsuccess");
        		flag1=1;
        		k=i;
        		
        	}
        	
    	/*  System.out.println("----------------");
    	   System.out.println("registered user amail"+st.get(i).email);
    	   System.out.println("registered user password"+st.get(i).pwd);
    	   System.out.println("----------------");*/
        }
      return  flag1;
      }
    public void getOptions() throws ClassNotFoundException, IOException
    {
    	 System.out.println("select your option");
    	 System.out.println("1:add money \n2:withdraw money\n3:exit/logout");
    	 int op=s.nextInt();
    	 switch(op)
    	 {
    	 case 1:
    		 Studentoperations sto=new Studentoperations();
    		 sto.credit();
    		 break;
    	 case 2: Studentoperations sto1=new Studentoperations();
		 sto1.debit();
    		break;
    
    	 }
    }


	public static void main(String[] args) throws IOException, Exception 
	{
		Studentlogin l1=new Studentlogin();
		l1.getLogin();
		
	}

}
