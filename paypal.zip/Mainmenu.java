package source1;
//import java.io.IOException;
import java.util.*;

public class Mainmenu 
{
     public static void show() throws Exception
     {
    	 Scanner s=new Scanner(System.in);
    	 System.out.println("welcomw to paypal");
    	 System.out.println("------------------------");
    	 while(true)
    	 {
    	 System.out.println("enter your choice\n 1. Sign in with email address\n2.create a new account \n3:exit");
    	 int ch=s.nextInt();
    	 switch(ch)
    	 {
    	 case 1:
    		 System.out.println("logindetails");
    		 System.out.println("enter your option \n1.Personal account \n2.Student account \n3.Bussiness account");
        	 int op=s.nextInt();
        	 switch(op)
        	 {
        	 case 1:
    		Logindetails l=new Logindetails();
    		int j=l.getLogin();
    		if(j==1)
    		{
    			l.getOptions();	
    		}
    		else
    		{
    			System.out.println("login failed try again");
        		l.getLogin();
    		}
    		
    		 break;
        	 case 2:System.out.println("student login");
        		 Studentlogin stl=new  Studentlogin();
        		int k= stl.getLogin();
        		System.out.println(k);
        		if(k==1)
        		{
        			System.out.println("login success+k"+k);
        			
        			stl.getOptions();	
        		}
        		else
        		{
        			System.out.println("login failed try again");
            		stl.getLogin();
        		}
        		}
        	 System.out.println("task completed");
        	 break;
    	 case 2:
    	 System.out.println("enter your option \n1.Personal account \n2.Student account \n3.Bussiness account");
    	 int op1=s.nextInt();
    	 switch(op1)
    	 {
    	 case 1:System.out.println("personal account");
    	 Personalaccount p=new Personalaccount();
    	 p.getDetails();
    	 p.activation();
    	 p.checkActivation();
    	 break;
    	 case 2:System.out.println("Student account");
    	 Student st=new Student();
    	 st.getDetails();
    	 st.activation();
    	 st.checkActivation();
    	 break;
    	 case 3:System.out.println("Bussiness  account");
    	 break;
    	 }
    	 System.out.println("task completed");
    	 break;
    	 case 3:
    		 System.out.println("thankyou for using paypal");
    		 break;
    	 }
    	 
     }
     }
     public static void main(String[] args)throws Exception
 	{
    	 Mainmenu m=new Mainmenu();
    	 show();
 	}
     
}
