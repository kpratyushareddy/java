package source1;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Operations  //implements Serializable
{
	/* addding mney to the account
	 * 
	 * check th eaccount existing or not updatig balance
	 * setting intial balance to
	 * 
	 *  
	 */
	int flag=0;
	float l;
	 String mail;
	 int j;
	//String ttime,tday;
	Scanner s=new Scanner(System.in);
	 @SuppressWarnings({ "unchecked", "unused" })
	void credit() throws IOException, ClassNotFoundException
		{
		 float c;
	 
		 System.out.println("enter money to credit");
		 c=s.nextFloat();
		System.out.println("enter mailid");
		 mail=s.next();
		Personal ac1;
		 FileInputStream fos=new FileInputStream("paypal/personal1.txt");
	        @SuppressWarnings("resource")
			ObjectInputStream out=new  ObjectInputStream(fos);
	    	ArrayList<Personal>p;
	        p=(ArrayList<Personal>)out.readObject();
	        for(j=0;j<p.size();j++)
		    {
	        	if(p.get(j).email.equals(mail))
	        	{
	        	l= p.get(j).bal;
	                 System.out.println(l);
	                 break;
	        	}
		    }
	        l=(l+c);
		  flag=1;
			System.out.println("balance in the current account is "+l);
			 Date objDate = new Date(); // Current System Date and time is assigned to objDate
			  System.out.println(objDate);
			  FileOutputStream fos1=new FileOutputStream("paypal/personal1.txt");
		        @SuppressWarnings("resource")
				ObjectOutputStream out1=new  ObjectOutputStream(fos1);
			  ac1=p.get(j);
	        	p.remove(p.get(j));
	        	ac1.bal=l;
	        	p.add(ac1);
	        	out1.writeObject(ac1);
			  System.out.println("accoutn logout "); 
			  
		  }
		
		@SuppressWarnings({ "unchecked", "resource" })
		void debit() throws IOException, ClassNotFoundException
		{
			System.out.println("enter money to withdraw");
			float d=s.nextFloat();
			System.out.println("enter mailid");
			 mail=s.next();
			FileInputStream fos=new FileInputStream("paypal/personal1.txt");
	        ObjectInputStream out=new  ObjectInputStream(fos);
	    	ArrayList<Personal>p;
	        p=(ArrayList<Personal>)out.readObject();
	        Personal ac1;
	        for(j=0;j<p.size();j++)
		    {
	        	if(p.get(j).email.equals(mail))
	        	{
	        	    l= p.get(j).bal;
	                break;
	        	}
		    }
		  		   if(l<d)
			   {
				 
				  System.out.println("balance is low");	  
			       }
		    else
			  {
		    	 
			        l=l-d;
			       System.out.println("balance in the account is "+l);
			      FileOutputStream fos1=new FileOutputStream("paypal/personal1.txt");
			        ObjectOutputStream out1=new  ObjectOutputStream(fos1);
                    ac1=p.get(j);
		        	p.remove(p.get(j));
		        	ac1.bal=l;
		        	p.add(ac1);
		        	out1.writeObject(ac1);
		        	out1.close();
		        	Date objDate = new Date(); // Current System Date and time is assigned to objDate
					  System.out.println(objDate); 
			       
			    }
		   System.out.println("accoutn logout ");  
		   if(flag==1)
		 {
			 System.out.println("transaction completd"); 
		 }
		 else
		 {
			 System.out.println("transaction failed"); 
		 }
		} 
		@SuppressWarnings("unchecked")
		void requestToSend() throws ClassNotFoundException, IOException
		{
			int c=0;
			System.out.println("enter use to send he request");
			String mailid=s.next();
			FileInputStream fos=new FileInputStream("paypal/personal1.txt");
	        @SuppressWarnings("resource")
			ObjectInputStream out1=new  ObjectInputStream(fos);
			 ArrayList<Personal>p1;
			    p1=(ArrayList<Personal>)out1.readObject();
			    for(int i=0;i<p1.size();i++)
			    {
			    	if(p1.get(i).email.equals(mailid))
	        	 {
	        	 System.out.println("request send to the respective user"); 
	        	 break;
	        	 }
	        	 else
	        	 {
	        	  c++;
	        	  }
	            }
			    if(c==p1.size())
			    {
			    	System.out.println("requested user is invalid");
			    	
			    }
		}
}
	        	  
	        	 
		
		    	/* public static void main(String[] args)throws Exception
		    		{
		    	    Operations o=new Operations();
		    	     o.addmoney(c);
		    	    	
		    	    		}*/



